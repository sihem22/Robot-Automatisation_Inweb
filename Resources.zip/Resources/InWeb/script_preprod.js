var botmanTarget = window.document.getElementsByClassName('crc-mainContent')[0];
var botmanData = {
    "botId" : "98e91d2a-a940-47e3-a7ff-df427c28c38d",
    "DOMtarget": botmanTarget,
    "user_input": "+",
    "onboarding": false,
    "printUserInput": false,
    "isWebchatOpened": false,
    "context": {
        "liveboxType": "Livebox 3",
        "scriptCode": "DIAG_RESEAU_LOCAL_CNXKO"
    },
    "fullContactStrategy": true,
    "burgerMenuDefaultOpen": false,
    "brand": "orange"
};

var script = window.document.createElement('script');
script.onload = function() {
    console.log("Script loaded and ready");
};
script.src = 'https://botman-preprod.apps.fr01.paas.diod.orange.com/appWebChatng/public/webChat-resp-preprod-diod.js?' + new Date().getTime();
window.document.getElementsByTagName('head')[0].appendChild(script);

console.log(botmanData); // Afficher les données dans la console

window.botmanData = botmanData; // Définir botmanData comme une propriété de window pour la rendre accessible globalement

var script = window.document.createElement('script');
script.onload = function() {
    console.log("Script loaded and ready");
};

