#Les Xpath de la réponse du Bot
Bot_response_Bloc1: str="//*[@id=\"botman-app-container\"]/div/app-chat/div/div[2]/div/app-discussion/app-bot-message["
Bot_response_Bloc2="]/div/div[2]"

#Les Xpath pour la saisie du message de l'utilisateur
locator_messages_textfield="xpath=//input[@id='messageSide']"
locator_sending_messages="xpath=//button[@id='sender']"

#les Xpath pour les boutons Quick Reply : pour appuyer sur les boutons Quick Replies
locator_iframe="xpath=//iframe[contains(@id,'botmanapp_iframe_botman')]"
locator_Mobile="Xpath=//button[contains(text(),'Mobile')]"
locator_Solde_credit="Xpath=//button[contains(text(),'Solde crédit')]"
locator_Francais="Xpath=//button[contains(text(),'Français')]"
locator_Coin_pratique="Xpath=//button[contains(text(),'Coin pratique')]"
locator_Paramétrer_internet="Xpath=//button[contains(text(),'Paramétrer internet')]"
locator_Oui="Xpath=//button[contains(text(),'Oui')]"
locator_Non="Xpath=//button[contains(text(),'Non')]"
locator_sos_credit_data="Xpath=//button[contains(text(),'SOS Crédit/Data')]"
locator_happy_path="Xpath=//button[contains(text(),'HAPPY PATH')]"
locator_sos_credit="Xpath=//button[contains(text(),'SOS Crédit')]"
locator_sos_data="Xpath=//button[contains(text(),'SOS Data')]"
locator_forfait="Xpath=//button[contains(text(),'Forfaits')]"
locator_api_dispo="Xpath=//button[contains(text(),'Api dispo')]"
locator_api_non_dispo="Xpath=//button[contains(text(),'Api non dispo')]"
locator_Orange_money="Xpath=//button[contains(text(),'Orange Money')]"
locator_Gestion_compte="Xpath=//button[contains(text(),'Gestion de compte')]"
locator_code_secret= "Xpath=//button[contains(text(),'Code secret')]"
locator_client_eligible= "Xpath=//button[contains(text(),'Client éligible')]"
#locator_lienauthentification="Xpath=//button[contains(text(),'Donner les infos')]"
locator_lienauthentification="Xpath=//span[contains(text(),'Donner les infos')]"
locator_clienteligible ="Xpath=//button[contains(text(),'Client éligible')]"
#locator_Video="[app-video-container[@class='video-bubble ng-star-inserted']"
locator_Video="xpath=//video[contains(@class, 'videoInChat')]"
locator_Oui_pousse="xpath=//button[contains(@class, 'ob1-quick-reply') and contains(@class, 'sliderBtn')]"
locator_Non_pousse="xpath=//button[contains(@class, 'ob1-quick-reply') and contains(@class, 'sliderBtn')]"
locator_Ouvrir_compte="Xpath=//button[contains(text(),'Ouvrir un compte')]"
locator_solde_orange_money="Xpath=//button[contains(text(),'Solde Orange Money')]"
locator_version_FAQ="Xpath=//button[contains(text(),'Version FAQ')]"
locator_historique="Xpath=//button[contains(text(),'Historique')]"
locator_transactions="Xpath=//button[contains(text(),'Transactions')]"
locator_transfert_argent="Xpath=//button[contains(text(),'Transfert d’argent')]"
locator_dans_mon_pays="Xpath=//button[contains(text(),'Dans mon pays')]"
locator_de_etranger="Xpath=//button[contains(text(),'De l’étranger')]"
locator_internet="Xpath=//button[contains(text(),'Internet')]"
locator_1_jour="Xpath=//button[contains(text(),'1 jour')]"
locator_Changer_forfait="Xpath=//button[contains(text(),'Changer de forfait')]"
locator_7_jour="Xpath=//button[contains(text(),'7 jours')]"
locator_30_jour="Xpath=//button[contains(text(),'30 jours')]"
locator_mixte="Xpath=//button[contains(text(),'Mixte')]"
locator_code_puk="Xpath=//button[contains(text(),'Code PUK')]"
locator_mon_num="Xpath=//button[contains(text(),'Mon numéro')]"
























